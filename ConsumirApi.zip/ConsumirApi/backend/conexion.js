const {error} = require("console")
const express = require("express")
const cors = require("cors")
const mysql = require("mysql")


const app = express();
const puerto = 3000;

//configuracion de la conexion con la BD
const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "tienda"
});

// establecer connexion a la BD 
db.connect((err)=>{
    if(err){
        console.error("Error al conectar a la BD" + err)
    }
    console.log("Conectado a la BD FELICIDADES BB");
});

//deshabilitar los boqueos al servidor
app.use(cors());

//ejecutar el servidor 
app.listen(puerto, ()=>{
    console.log("Servidor en el puerto 3000");
});

//cibvertir los datos a de la BD a JSON
app.use(express.json());

//ruta para obtener los datos de la BD
app.get("/productos", function(req, res){
    db.query("SELECT * FROM productos", (err, result)=>{
        if (err){
            console.log("Error al obtener el producto" +err);
            res.status(500).json({error:"error con la tabla productos"})
            return;
        }
        res.json(result);
    })
})