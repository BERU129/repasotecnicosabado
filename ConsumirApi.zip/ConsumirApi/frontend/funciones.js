const d= document;

let tabla = d.querySelector(".table tbody");

d.addEventListener("DOMContentLoaded", function(){
    mostrarDatos();
})

//funcion para mostrar los datos de la BD

function mostrarDatos(){
    fetch("http://localhost:3000/productos")
    .then(res => res.json())
    .then(data => {
        data.forEach((pro) => {
            let fila = d.createElement("tr");
            fila.innerHTML=` 
            <td> ${pro.id_producto} </td>
            <td> ${pro.nombre} </td>
            <td> ${pro.presentacion} </td>
            <td> ${pro.precio} </td>
            <td> <img src=" ${pro.imagen}" whidth="20%"> </td>
            `;
            tabla.appendChild(fila);
        })
    })
    .catch(res => console.log(res))
}