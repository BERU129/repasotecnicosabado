const d= document;

let tabla = d.querySelector(".table tbody");
let nombrePro = d.querySelector(".nombre-pro")
let precioPro = d.querySelector(".precio-pro")
let presenPro = d.querySelector(".presen-pro")
let imagenPro = d.querySelector(".imagen-pro")
let btnGuardar = d.querySelector(".btn-guardar")


d.addEventListener("DOMContentLoaded", function(){
    mostrarDatos();
})
//agregar evento boton
btnGuardar.addEventListener("click", function(){
    ObtenerDatos();
});

//funcion obtener datos del formulario
function ObtenerDatos() {
    if (nombrePro.value == "" || presenPro.value == "" || precioPro.value == "" || imagenPro.value == ""){
        alert("Escriba por favor")
    }
    let datosForm = {
        nombre : nombrePro.value,
        presentacion : precioPro.value,
        precio : precioPro.value,
        imagen : imagenPro.value
    }
    console.log(datosForm);
    //pasarle los datos
    enviarDatos(datosForm)
    alert("Producto guardado con exito BB")
    mostrarDatos();
}


//funcion para enviar datos
 function enviarDatos(nuevoPro){
    let url = "http://localhost:3000/productos"
    fetch(url, {
       method : "POST",
       headers: {
        "Content-Type" : "application/json"
       },
       body : JSON.stringify(nuevoPro) 
    })
    .then(respuesta=>respuesta.text())
    .then(mensaje=>console.log(mensaje))
    .catch(error => console.log("Error al guardar el producto: "+error))
}

//funcion para mostrar los datos de la BD

function mostrarDatos(){
    fetch("http://localhost:3000/productos")
    .then(res => res.json())
    .then(data => {
        data.forEach((pro) => {
            let fila = d.createElement("tr");
            fila.innerHTML=` 
            <td> ${pro.id_producto} </td>
            <td> ${pro.nombre} </td>
            <td> ${pro.presentacion} </td>
            <td> ${pro.precio} </td>
            <td> <img src=" ${pro.imagen}" whidth="20%"> </td>
            `;
            tabla.appendChild(fila);
        })
    })
    .catch(res => console.log(res))
}